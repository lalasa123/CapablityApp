import React,{Component} from 'react';
import './questionTopic.css';
import {NavLink} from 'react-router-dom';

class QuestionTopic extends Component{
    constructor(props){
        super(props)
    }
    handleTopic=()=>{
      document.getElementById("trs").style.display="block";
     // var markUp='<tr><td><input type="text" /></td><td><input type="text" /></td><td><label class="switch"><input type="checkbox"  /><span class="slider round"></span></label></td><td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>'
    
    }
    render(){
        return(
            <div>
                <div>
                    <br />
           <button type="button" id="btn" value="add question topic" class="btn btn-primary" onClick={this.handleTopic}>Add Question Topic</button>
                </div>
                <div>
                    <br />
                    <br />
                    <table id="tbl"  >
                    <tr><th>Name</th><th>Acronym</th><th>Status</th><th>Action</th></tr>
                    <hr />
                    <tr id="trs">
                    <td><input type="text"/></td>
                    <td><input type="text"/></td>
                    <td><label class="switch">
                    <input type="checkbox"  />
                    <span class="slider round"></span></label></td>
                    <td><button type="button" class="btn btn-primary" value="edit">edit</button></td>
                    </tr>
                    
                    {/* Topic-React Js */}
                    <tr><td>React JS</td>
                    <td>React JS</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <hr />
                 {/* Topic-My Sql */}
                 <tr><td>My Sql</td>
                    <td>My Sql</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <hr />
                 {/* Topic-PHP */}
                 <tr><td>PHP</td>
                    <td>PHP</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <hr />
                 {/* Topic-Javascript  */}
                 <tr><td>Javascript</td>
                    <td>Javascript</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                <hr />
                 {/* Topic-Angular Js */}
                 <tr><td>Angular JS</td>
                    <td>Angular JS</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                    </table>
                    
                    <br/>
                    <br/>

                
            
            </div> 
                </div>
        )
    }
}
export default QuestionTopic;