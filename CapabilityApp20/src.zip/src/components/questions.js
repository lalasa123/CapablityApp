import React,{Component} from 'react';
import './questions.css';
import {NavLink} from 'react-router-dom';

class Questions extends Component{
    constructor(props){
        super(props)
    }
    handleQuestion=()=>{

    }
    render(){
        return(
            <div>
            <div>
                <br />
                
           <button type="button" id="btn" value="add question " ><NavLink to='/questionsPage' color="black">Add Question</NavLink></button>
                </div>
                <br />
                <br />
            <div>
                <table id="tblQues">
                    <tr><th>S.No</th><th>Questions</th><th>Type</th>
                    <th>Complexity</th><th>Status</th><th>Action</th></tr><hr />
                    <tr><td>1</td><td>what is React</td><td>Single</td><td>Simple</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label>
               </td>
               <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
               <hr />
               <tr><td>2</td><td>What is state in React</td><td>Multiple</td><td>Moderate</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label>
               </td>
               <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
               <hr />
               <tr><td>3</td><td>Image</td><td>Query</td><td>Complex</td>
                    <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label>
               </td>
               <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
  
                    </table>
                </div>
            </div>
        )
    }
}
export default Questions;