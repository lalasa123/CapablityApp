import React,{Component} from 'react';
import './questionTopic.css';

class QuestionType extends Component{
    constructor(props){
        super(props)
    }
    handleType=()=>{
        document.getElementById("tr").style.display="block";
    }
    render(){
        return(
            <div>
            <div>
          <br />
          <br />
           <button type="button" id="btn" value="add question type" class="btn btn-primary" onClick={this.handleType}>Add Question Type</button>
                </div>
                <div>
                    <br />
                    <br />
                    <table id="tbl"  >
                    <tr><th>Name</th><th>Acronym</th>Status<th>Action</th></tr>
                    <hr />
                    
                 <tr><td>Single</td><td>Single</td>
                 <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <hr />
                 <tr><td>Multiple</td><td>Multiple</td>
                 <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <hr />
                 <tr><td>Query</td><td>Query</td>
                 <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 </table>
                 </div>
                 </div>
        )
    }
}
export default QuestionType;