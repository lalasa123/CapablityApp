import React,{Component} from 'react';

class QuestionChoice extends Component{
    render(){
        return(
         <h1>QuestionChoice Component</h1>
        )
    }
}
export default QuestionChoice;