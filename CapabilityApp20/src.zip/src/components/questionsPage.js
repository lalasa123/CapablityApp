import React,{Component} from 'react';
import './questionPage.css';    

class QuestionsPage extends Component{
    constructor(props){
        super(props)
    }
    handleQuestions=()=>{
      var type=document.getElementById("drpType").value;
      //alert(type);
      if(type=="Single"){
document.getElementById("sType").style.display="block";
      }
      else if(type=="Multiple"){
          document.getElementById("sType").style.display="block";
      }
      else if(type=="Query"){
          document.getElementById("qType").style.display="block";
      }
    }
    render(){
        return(
          <div> 
              <br />
              
              <table id="tblPage">
                  <tr><td>
              <label>Select Topic</label>
              <select>
              <option>--Select--</option>
                  <option>React Js</option>
                  <option>My Sql</option>
                  <option>PHP</option>
                  <option>Javascript</option>
                  <option>Angular JS</option>
                  </select>
                  </td>
                  <td>
                  <label>Select Complexity</label>
              <select>
              <option>--Select--</option>
                  <option>Simple</option>
                  <option>Moderate</option>
                  <option>Complex</option>
                  
                  </select ></td>
                  <td>
                  <label>Select Type</label>
              <select id="drpType" onChange={this.handleQuestions}>
                  <option>--Select--</option>
                  <option>Single</option>
                  <option>Multiple</option>
                  <option>Query</option>
                  
                  </select></td>
                  </tr>
</table>
<br />
<br />
<div id="sType">
<table id="tblQpage">
    <tr>
    <textarea rows="4" cols="100" id="txArea"></textarea></tr><br /><br />
<tr><td><label>a.</label><input type="text"/></td>
<td><label>b.</label><input type="text"/></td>
</tr>
<tr><td><label>c.</label><input type="text"/></td>
<td><label>d.</label><input type="text"/></td></tr>
</table>
<div id="divbtn">
    <button type="button" value="save" class="btn btn-primary">Save</button>
    <button type="button" value="Cancel" class="btn btn-warning">Cancel</button>
    </div>
    </div>
    <div id="qType">
<table id="tblQpage">
    <tr>
     <textarea rows="10" cols="100" id="txArea"></textarea></tr><br /><br />
 <tr><td><label>Upload Image:</label></td><input type="file" /></tr>
</table>
<div id="divbtn">
    <button type="button" value="save" class="btn btn-primary">Save</button>
    <button type="button" value="Cancel" class="btn btn-warning">Cancel</button>
    </div>
    </div>
          </div>
        )
    }
}
export default QuestionsPage;