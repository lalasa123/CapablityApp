import React,{Component} from 'react';
import './dashboard.css';


class Dashboard extends Component{
    render(){
        return(
        <h2>Welcome to Capability Test App</h2>
    )
    }
}
export default Dashboard;