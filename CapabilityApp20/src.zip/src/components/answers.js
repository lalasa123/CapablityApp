import React,{Component} from 'react';

class Answers extends Component{
    render(){
        return(
         <h1>Answers Component</h1>
        )
    }
}
export default Answers;