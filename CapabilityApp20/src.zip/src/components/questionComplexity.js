import React,{Component} from 'react';
import './questionTopic.css';

class QuestionComplexity extends Component{
    constructor(props){
        super(props)
    }
    handleComplexity=()=>{
        document.getElementById("trs").style.display="block";
    }
    render(){
        return(
            <div>
            <div>
                <br />
                
           <button type="button" id="btn" value="add question type" class="btn btn-primary" onClick={this.handleComplexity}>Add Question Complexity</button>
                </div>
                <div>
                    <br />
                    <br />
                    <table id="tbl"  >
                    <tr><th>Name</th><th>Acronym</th><th>Status</th><th>Action</th></tr>
                    <hr />
                    <tr id="trs"><td><input type="text" /></td><td><input type="text" /></td>
                    <td><label class="switch"><input type="checkbox"  /><span class="slider round"></span></label></td>
                    <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <tr><td>Simple</td><td>Simple</td>
                 <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <hr />
                 <tr><td>Moderate</td><td>Moderate</td>
                 <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 <hr />
                 <tr><td>Complex</td><td>Complex</td>
                 <td><label class="switch">
                     <input type="checkbox"  />
                 <span class="slider round"></span></label></td>
                 <td><button type="button" class="btn btn-primary" value="edit">edit</button></td></tr>
                 </table>
                 </div>
                 </div>
        )
    }
}
export default QuestionComplexity;